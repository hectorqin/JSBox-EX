const BDPan = require('scripts/api');
const template = require("scripts/template")
const DataWatcher = require("scripts/DataWatcher")
const Util = require('scripts/util')

function saveConfig(data) {
    $cache.set("BDPAN_DATA", data)
}

function getConfig() {
    return $cache.get("BDPAN_DATA")
}

const CURRENT_VERSION = 1.0

const UNLOGIN_ACTION = {
    slient: 0,
    showLogin: 1,
    toast: 2
}

const MSEARCH_URLS = [{
        name: "磁力猫",
        pattern: "http://www.cilimao.me/api/search?size=10&sortDirections=desc&page=__PAGE__&word="
    }, {
        name: "种子搜",
        pattern: "http://bt.xiandan.in/api/search?source=%E7%A7%8D%E5%AD%90%E6%90%9C&page=__PAGE__&keyword="
    }, {
        name: "磁力吧",
        pattern: "http://bt.xiandan.in/api/search?source=%E7%A3%81%E5%8A%9B%E5%90%A7&page=__PAGE__&keyword="
    }, {
        name: "屌丝搜",
        pattern: "http://bt.xiandan.in/api/search?source=%E5%B1%8C%E4%B8%9D%E6%90%9C&page=__PAGE__&keyword="
    }, {
        name: "BT樱桃",
        pattern: "http://bt.xiandan.in/api/search?source=BT%E6%A8%B1%E6%A1%83&page=__PAGE__&keyword="
    }, {
        name: "BT兔子",
        pattern: "http://bt.xiandan.in/api/search?source=BT%E5%85%94%E5%AD%90&page=__PAGE__&keyword="
    }, {
        name: "AOYOSO",
        pattern: "http://bt.xiandan.in/api/search?source=AOYOSO&page=__PAGE__&keyword="
    }
]

let ROOT_PATH = '/'
let dataWatcher = new DataWatcher(Util.extend(getConfig() || {}, {
    thumbs: true,
    accountList: {},
    nowAccount: {}
}))
let BDPAN_DATA = dataWatcher.getData()
let cacheFileList = {}

let playLocal = false
let localServer = ""

let videoShowing = {}
let playingFile = null
let playingFolder = null

let mSearchWord = ""

let sharePath = ""

console.log(BDPAN_DATA)
let ukList = Object.keys(BDPAN_DATA.accountList)
if (!ukList.length) {
    $ui.toast("您还没有添加账号呢")
} else {
    BDPAN_DATA.nowAccount = BDPAN_DATA.nowAccount.cookie ? BDPAN_DATA.nowAccount : BDPAN_DATA.accountList[ukList["0"]]
}

let $BDPan = null

function checkLogin(unloginAction, cookie = false) {
    let $$BDPan = $BDPan
    if (cookie) {
        $$BDPan = new BDPan(cookie)
    }
    $$BDPan.getContext().then((data) => {
        console.log("Context..")
        console.log(data)
        if (!data) {
            if (unloginAction == UNLOGIN_ACTION.showLogin) {
                $ui.alert({
                    title: "登录已过期",
                    message: "当前帐号登录已过期，请重新登录",
                    actions: [{
                            title: "OK",
                            handler: function() {
                                showLogin()
                            }
                        },
                        {
                            title: "Cancel",
                            handler: function() {
                                console.log("cancel")
                            }
                        }
                    ]
                })
            } else if (unloginAction == UNLOGIN_ACTION.toast) {
                $ui.toast("好像没登录哦")
            }
        } else if (cookie) {
            // 新增账号或重新登录
            let typeName = BDPAN_DATA.accountList[data.uk] ? "重新登录" : "添加";
            BDPAN_DATA.accountList[data.uk] = {
                username: data.username,
                uk: data.uk,
                photo: data.photo,
                cookie: cookie,
                valid: true
            }
            console.log(BDPAN_DATA)
            saveConfig(BDPAN_DATA)
            $ui.toast(`${typeName}账号${data.username}成功`)
        } else {
            // 校验当前帐号cookie有效
            BDPAN_DATA.nowAccount.valid = true
            saveConfig(BDPAN_DATA)
        }
    })
}


function init() {
    $BDPan = new BDPan(BDPAN_DATA.nowAccount.cookie || "")

    cacheFileList = $cache.get("BDPAN_FILE_LIST_" + BDPAN_DATA.nowAccount.uk)
    renderFileList(ROOT_PATH)

    if (BDPAN_DATA.nowAccount) {
        BDPAN_DATA.nowAccount.valid = false
        checkLogin(UNLOGIN_ACTION.showLogin)
    }
}

//检测扩展更新
function checkVersion() {
    $http.get({
        url: "https://raw.githubusercontent.com/hectorqin/JSBox-EX/master/BDPan/updateInfo",
        handler: function(resp) {
            var newVersion = resp.data.version;
            var msg = resp.data.msg;
            if (newVersion > CURRENT_VERSION) {
                $ui.alert({
                    title: "检测到新的版本！V" + newVersion,
                    message: "是否更新?\n更新完成后请退出至扩展列表重新启动新版本。\n" + msg,
                    actions: [{
                        title: "更新",
                        handler: function() {
                            var url = `jsbox://install?url=https://github.com/hectorqin/JSBox-EX/releases/download/v${newVersion}/jsbox.zip`;
                            $app.openURL(url);
                            $app.close()
                        }
                    }, {
                        title: "取消"
                    }]
                })
            }
        }
    })
}

async function getFileList(path = "/", refresh = false) {
    if (!refresh && cacheFileList[path]) {
        return cacheFileList[path];
    }
    let data = await $BDPan.getFileList(path, false)
    console.log("获取data")
    console.log(data)
    cacheFileList[path] = data.list
    $cache.set("BDPAN_FILE_LIST_" + BDPAN_DATA.nowAccount.uk, cacheFileList)
    return cacheFileList[path];
}

function showCreateFolder(path) {
    $input.text({
        placeholder: "新建文件夹",
        handler: function(text) {
            if (text.indexOf("/") !== -1) {
                $ui.toast("文件名不能包含非法字符")
                return;
            }
            $BDPan.mkdir(path + '/' + text).then((data) => {
                if (data) {
                    $ui.toast("创建文件夹成功")
                    renderFileList(path, true)
                } else {
                    $ui.toast("创建文件夹失败")
                }
            }).catch((e) => {
                console.log(e)
                $ui.toast("报错啦  " + JSON.stringify(e))
            })
        }
    })
}

function showDeleteConfirm(path, file) {
    $ui.alert({
        title: "操作确认",
        message: "确认删除该" + (file.isdir ? "文件夹" : "文件") + "吗？",
        actions: [{
                title: "确定",
                handler: function() {
                    $BDPan.remove(file.path, () => {
                        $ui.toast("操作成功")
                        renderFileList(path, true)
                    }).then((data) => {
                        $ui.toast("操作提交" + (data ? "成功" : "失败"))
                    })
                }
            },
            {
                title: "取消",
                handler: function() {
                    console.log("cancel")
                }
            }
        ]
    })
}

async function showShareInput(path, file) {
    let text = await $input.text({
        placeholder: "请输入分享密码(4位字符，为空自动生成)"
    })
    if (text && text.length != 4) {
        $ui.toast("分享密码为4位字符")
        return;
    } else if (!text) {
        text = Math.random().toString(36).replace(/[^\w]*/g, 'a').substr(-4);
    }
    let result = await $BDPan.share(file.path, text)
    if (result) {
        $clipboard.text = `链接：${result.shorturl} 密码：${text}`;
        $ui.toast($clipboard.text)
    } else {
        $ui.toast("分享失败")
    }
}

async function showLogin() {
    let result = await $ui.menu({ items: ["手动输入cookie(推荐)", "web登录获取(有bug)"] })
    if (result.index == 0) {
        $input.text({
            placeholder: "请输入cookie",
            handler: function(text) {
                if (!text) {
                    $ui.toast("cookie不能为空")
                    return;
                }
                checkLogin(UNLOGIN_ACTION.toast, text)
            }
        })
    } else {
        renderLoginView()
    }
}

async function showMenu(path, subPage) {
    let listId = getFileListId(path)
    let menuList = ["磁力下载", "上传文件", "全选视频", "全选", "全不选"]
    if (!subPage) {
        menuList.push("账号管理")
    }
    let result = await $ui.menu({ items: menuList })
    console.log(result)
    switch (result.title) {
        case "磁力下载":
            queryMagnetInfo()
            break;
        case "账号管理":
            showAccountSwitch()
            break;
        case "上传文件":
            $ui.toast("待完成")
            // uploadFile()
            break;
        case "全选视频":
            selectListFile(listId, "videofile")
            break;
        case "全选":
            selectListFile(listId, "SELECT_ALL")
            break;
        case "全不选":
            selectListFile(listId, "SELECT_NONE")
            break;
        default:
            break;
    }
}

async function showAccountSwitch() {
    let accountList = []
    let nowAccountIndex = 0
    let accountUK = []
    for (let k in BDPAN_DATA.accountList) {
        if (BDPAN_DATA.nowAccount.uk == k) {
            nowAccountIndex = accountList.length
        }
        let isNow = k == BDPAN_DATA.nowAccount.uk ? "(当前登录)" : ""
        accountList.push(isNow + BDPAN_DATA.accountList[k]['username'])
        accountUK.push(BDPAN_DATA.accountList[k]['uk'])
    }
    accountList.push("添加账号")
    let result = await $ui.menu({ items: accountList })
    console.log(result)
    if (result.index == accountList.length - 1) {
        showLogin()
    } else if (result.index != nowAccountIndex) {
        // 切换用户
        BDPAN_DATA.nowAccount = BDPAN_DATA.accountList[accountUK[result.index]]
        saveConfig(BDPAN_DATA)
        init()
    }
}

async function uploadFile() {
    // let data = await $driver.open()
    let data = await $photo.pick()
    console.log(data)
    if (data.image) {
        $ui.toast("待完成")
        // $http.upload({
        //     url: "http://upload.qiniu.com/",
        //     form: {
        //         token: "<token>"
        //     },
        //     files: [{
        //         "image": image,
        //         "name": "file",
        //         "filename": "file.png"
        //     }],
        //     progress: function(percentage) {

        //     },
        //     handler: function(resp) {

        //     }
        // })
    }
}

function renderLoginView(replace) {
    let isLogin = false
    let view = {
        props: {
            title: $l10n("BAIDU_PAN"),
        },
        views: [{
                type: "button",
                props: {
                    title: "Web版",
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.left.inset(10)
                    make.height.equalTo(40)
                    make.width.equalTo(80)
                },
                events: {
                    tapped: function(sender) {
                        $("login-web").eval({
                            script: "location.href='http://pan.baidu.com/disk/home?adapt=pc'",
                            handler: function(result, error) {
                                console.log(result)
                                console.log(error)
                            }
                        })
                    }
                }
            },
            {
                type: "button",
                props: {
                    title: "Wap版",
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.left.inset(100)
                    make.height.equalTo(40)
                    make.width.equalTo(80)
                },
                events: {
                    tapped: function(sender) {
                        $("login-web").eval({
                            script: "location.href='http://pan.baidu.com/wap/welcome'",
                            handler: function(result, error) {
                                console.log(result)
                                console.log(error)
                            }
                        })
                    }
                }
            },
            {
                type: "button",
                props: {
                    title: "清除登录",
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.right.inset(100)
                    make.height.equalTo(40)
                    make.width.equalTo(80)
                },
                events: {
                    tapped: function(sender) {
                        $("login-web").eval({
                            script: "document.cookie = ''",
                            handler: function(result, error) {
                                console.log(result)
                                console.log(error)
                            }
                        })
                    }
                }
            },
            {
                type: "button",
                props: {
                    title: "已登录",
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.right.inset(10)
                    make.height.equalTo(40)
                    make.width.equalTo(80)
                },
                events: {
                    tapped: function(sender) {
                        $("login-web").eval({
                            script: "$notify('returnCookie', document.cookie)",
                            handler: function(result, error) {
                                console.log(result)
                                console.log(error)
                            }
                        })
                    }
                }
            },
            {
                type: "web",
                props: {
                    id: "login-web",
                    url: "http://pan.baidu.com/disk/home?adapt=pc",
                    borderColor: $color("#dddddd")
                },
                layout: function(make, view) {
                    make.top.inset(50)
                    make.right.inset(10)
                    make.left.right.bottom.inset(0)
                },
                events: {
                    decideNavigation: function(sender, action) {
                        if (action.requestURL.indexOf('pan.baidu.com/wap') != -1) {
                            isLogin = true
                        }
                        return true
                    },
                    didFinish: function(sender, navigation) {
                        console.log(sender)
                        console.log(navigation)
                        if (isLogin) {
                            // 只能获取 pan.baidu.com 域的cookie
                            sender.eval({
                                script: "$notify('returnCookie', document.cookie)",
                                handler: function(result, error) {
                                    console.log(result)
                                    console.log(error)
                                }
                            })
                        }
                    },
                    didSendRequest: function(request) {
                        console.log(request)
                        var method = request.method
                        var url = request.url
                        var body = request.body
                    },
                    returnCookie: function(cookie) {
                        console.log("获取cookie")
                        console.log(cookie)
                        if (cookie) {
                            checkLogin(UNLOGIN_ACTION.toast, cookie)
                        }
                    }
                }
            }

        ]
    }
    if (replace) {
        $ui.render(view)
    } else {
        $ui.push(view)
    }
    $ui.toast("请登录获取cookie")
}

async function renderBTFile(file) {
    console.log("renderBTFile")
    let torrentInfo = await $BDPan.getTorrentInfo(file.path)
    console.log(torrentInfo)
    let data = torrentInfo.file_info.map((item, key) => {
        return template.convertBT(item, key)
    })
    console.log(data)
    renderBTFileView(file.path, data, torrentInfo.sha1)
}

async function queryMagnetInfo(url) {
    if (!url) {
        url = await $input.text({
            placeholder: "请输入磁链"
        })
        if (url.indexOf("magnet:") == -1) {
            $ui.toast("请输入正确的磁链")
            return
        }
    }
    $ui.toast("正在解析磁链...")
    let magnetInfo = await $BDPan.getMagnetInfo(url)
    console.log(magnetInfo)
    if (!magnetInfo) {
        $ui.toast("磁链解析失败")
        return
    }
    let data = magnetInfo.map((item, key) => {
        return template.convertBT(item, key)
    })
    console.log(data)
    renderBTFileView(url, data)
}

async function showShareInfo(url) {
    let result = await $BDPan.getShareInfo(url)
    console.log(result)
    renderShareInfo(result)
}

async function renderShareFileList(context, path) {
    sharePath = path
    let result = await $BDPan.getShareFileList(context['uk'], context['shareid'], path)
    console.log(result)
    $("share-file-list").data = result.list.map((item, key) => {
        return template.convert(item, key, BDPAN_DATA.thumbs)
    })
}

function renderShareInfo(context) {
    let data = context.file_list.list.map((item, key) => {
        return template.convert(item, key, BDPAN_DATA.thumbs)
    })
    $ui.push({
        props: {
            title: $l10n("BAIDU_PAN"),
        },
        views: [{
                type: "label",
                props: {
                    id: "select-label",
                    text: "已选择 0 项",
                    font: $font(16),
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.left.inset(10)
                    make.height.equalTo(40)
                }
            },
            {
                type: "button",
                props: {
                    title: "<",
                    bgcolor: $color("white"),
                    titleColor: $color("#333333")
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.right.inset(55)
                    make.height.equalTo(40)
                    make.width.equalTo(40)
                },
                events: {
                    tapped: function(sender) {
                        console.log('renderShareFileList')
                        renderShareFileList(context, Util.pathinfo(sharePath, 'PATHINFO_DIRNAME'))
                    }
                }
            },
            {
                type: "button",
                props: {
                    src: "assets/menu_18x18_@3x.png",
                    imageEdgeInsets: $insets(5, 5, 5, 5)
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.right.inset(10)
                    make.height.equalTo(40)
                    make.width.equalTo(40)
                },
                events: {
                    tapped: function(sender) {
                        console.log('showShareMenu')
                        showShareMenu(context)
                    }
                }
            },
            {
                type: "list",
                props: {
                    id: "share-file-list",
                    data: data,
                    template: template.list,
                    rowHeight: 60,
                    info: {
                        listSelectMap: {}
                    }
                },
                layout: function(make, view) {
                    make.top.inset(45)
                    make.left.bottom.right.equalTo(0)
                },
                events: {
                    didSelect: function(sender, indexPath, item) {
                        if (item.isdir) {
                            renderShareFileList(context, item.path)
                        }
                    }
                }
            }
        ]
    })
}

async function showShareMenu(context) {

}

function renderBTFileView(path, data, sha1 = '') {
    $ui.push({
        props: {
            title: $l10n("BAIDU_PAN"),
        },
        views: [{
                type: "label",
                props: {
                    id: "select-label",
                    text: "已选择 0 项",
                    font: $font(16),
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.left.inset(10)
                    make.height.equalTo(40)
                }
            },
            {
                type: "button",
                props: {
                    src: "assets/menu_18x18_@3x.png",
                    imageEdgeInsets: $insets(5, 5, 5, 5)
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.right.inset(10)
                    make.height.equalTo(40)
                    make.width.equalTo(40)
                },
                events: {
                    tapped: function(sender) {
                        console.log('showBTMenu')
                        showBTMenu(path, sha1)
                    }
                }
            },
            {
                type: "list",
                props: {
                    id: "bt-file-list",
                    data: data,
                    template: template.btList,
                    rowHeight: 60,
                    info: {
                        listSelectMap: new Array(data.length).fill(false)
                    }
                },
                layout: function(make, view) {
                    make.top.inset(45)
                    make.left.bottom.right.equalTo(0)
                }
            }
        ]
    })
}

async function showBTMenu(path, sha1) {
    let result = await $ui.menu({ items: ["离线下载", "全选视频", "全选", "全不选"] })
    console.log(result)
    switch (result.title) {
        case "离线下载":
            downloadBT(path, $("bt-file-list").info.listSelectMap, sha1)
            break;
        case "全选视频":
            selectListFile("bt-file-list", "videofile")
            break;
        case "全选":
            selectListFile("bt-file-list", "SELECT_ALL")
            break;
        case "全不选":
            selectListFile("bt-file-list", "SELECT_NONE")
            break;
        default:
            break;
    }
}

function selectListFile(listId, type = "") {
    let data = $(listId).data;
    console.log(data)
    console.log(type)
    let listSelectMap = $(listId).info.listSelectMap
    let count = 0
    data = data.map((item, index) => {
        if (type == "SELECT_ALL" || type == "SELECT_NONE") {
            item["select-button"] = {
                src: type == "SELECT_ALL" ? "assets/choose_select_14x14_@3x.png" : "assets/choose_defalut_13x13_@3x.png",
                info: {
                    "index": index,
                    "select": type == "SELECT_ALL" ? true : false
                }
            }
            listSelectMap[index] = type == "SELECT_ALL" ? true : false
        } else if (!type || (type && item["cate"] == type)) {
            item["select-button"] = {
                src: "assets/choose_select_14x14_@3x.png",
                info: {
                    "index": index,
                    "select": true
                }
            }
            listSelectMap[index] = true
        } else {
            item["select-button"] = {
                src: "assets/choose_defalut_13x13_@3x.png",
                info: {
                    "index": index,
                    "select": false
                }
            }
            listSelectMap[index] = false
        }
        if (listSelectMap[index]) {
            count++
        }
        return item
    })
    $(listId).info = Util.extend({}, $(listId).info, { listSelectMap: listSelectMap })
    $(listId).data = data
    if ($(listId).super.get("select-label")) {
        $(listId).super.get("select-label").text = `已选择 ${count} 项`
    }
}

function downloadBT(path, selectMap, sha1) {
    console.log(path)
    console.log(selectMap)
    let idx = []
    selectMap.map((value, key) => {
        if (value) idx.push(key)
    })
    if (!idx.length) {
        $ui.toast("请选择要离线下载的文件")
        return;
    }
    let dirname = path.indexOf('magnet:') != -1 ? '/' : Util.pathinfo(path, 'PATHINFO_DIRNAME')
    $BDPan.downloadBT(path, sha1, idx, dirname).then((data) => {
        $ui.toast("添加离线任务" + (data ? "成功" : "失败"))
    })
}

async function renderVideoFile(path, file, type = "M3U8_AUTO_480") {
    $ui.toast("获取视频播放地址...")
    $ui.loading(true)
    let pageId = getPageId(path)
    let data = await $BDPan.getM3u8(file.path, playLocal, type)
    console.log(data)
    if (videoShowing[path]) {
        $ui.loading(false)
        return changeVideoSource(data)
    }
    let views = [];
    let containerHeight = $(pageId).frame.height
    if (playLocal) {
        if (!$file.isDirectory("/cache")) {
            if (!$file.mkdir("/cache")) {
                $ui.toast("创建cache目录失败")
                return
            }
        }
        if (!$file.write({
                data: $data({ string: data }),
                path: "/cache/video.m3u8"
            })) {
            $ui.toast("创建文件失败")
            return
        }
        if (!localServer) {
            let result = await $http.startServer({
                port: 5588, // port number
                path: "/", // script foot path
            })
            console.log("startServer")
            console.log(result)
            localServer = result.url
        }
        views = renderVideoByLocalPage(localServer + "download?path=" + Util.urlencode("cache/video.m3u8"), "", containerHeight, playNextVideo)
    } else {
        views = renderVideoByBDPPage(data, "", containerHeight, playNextVideo)
    }
    if (!Util.isArray(views)) {
        views = [views]
    }
    views.forEach((view) => {
        $(pageId).add(view)
    })
    videoShowing[path] = true
    playingFile = file
    playingFolder = path
}

function playNextVideo() {
    if (!playingFolder || !playingFile || !videoShowing[playingFolder]) {
        return;
    }
    let listId = getFileListId(playingFolder)
    let data = $(listId).data
    for (let index = 0; index < data.length; index++) {
        if (index > playingFile.index && item.cate == 'videofile') {
            item.index = index
            return renderVideoFile(playingFolder, item)
        }
    }
    $ui.toast("已经播完啦")
}

function changeVideoSource(source) {
    let script = "";
    if (playLocal) {
        if (!$file.write({
                data: $data({ string: source }),
                path: "/cache/video.m3u8"
            })) {
            $ui.toast("创建文件失败")
            return
        }
        script = `video.load()`
    } else {
        script = `video.src='${source}';video.load()`
    }
    $("web-video").eval({
        script: script,
        handler: function(result, error) {
            console.log(result)
            console.log(error)
        }
    })
}

// 暂时无效
function renderVideoByLocalPage(src, poster = "", containerHeight = 0, onEnd = null) {
    const html = `<!DOCTYPE HTML>
    <html>
    <body style="background: #000000">
    <video id="video" style="width: 100vw;height: 100vh" controls="controls" src="${src}" poster="${poster}" autoplay playsinline webkit-playsinline>
    </video>
    <script>
        var video = document.getElementById("video");
        var touchHandle = function(){
            video.play();
            $notify('videoEvent', {'status': 'touch'})
        }
        video.addEventListener('touchstart', touchHandle, true)
        ['abort','canplay','canplaythrough','durationchange','emptied','ended','error','loadeddata','loadedmetadata','loadstart','pause','play','playing','progress','ratechange','readystatechange','seeked','seeking','stalled','suspend','timeupdate','volumechange','waiting'].forEach(function(event){
              video.addEventListener(event, eventHandle, false);
        });
        function eventHandle(e){
            $notify('videoEvent', {'event': e})
        }
        window.onerror = function(msg, url, line, col, error) {
            console.log(arguments)
            $notify('videoEvent', {'error': arguments})
        }
    </script>
    </body>
    </html>
    `
    // let totalHeight = $device.info.screen.height
    let totalHeight = containerHeight ? containerHeight : $device.info.screen.height - 64;
    let videoHeight = totalHeight > 256 ? 256 : totalHeight
    let position = [0, Math.round((totalHeight - videoHeight) / 2), totalHeight - videoHeight]
    let positionType = 0
    return [{
        type: "web",
        props: {
            id: "web-video",
            html: html,
            showsProgress: false,
        },
        layout: function(make, view) {
            make.left.right.equalTo(0)
            make.top.offset(position[positionType] + 0)
            make.height.equalTo(videoHeight)
        },
        events: {
            didFinish: function(sender, navigation) {

            },
            videoEvent: function(params) {
                console.log(params)
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-speed",
            title: "1.0",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222")
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 60)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: async function(sender) {
                console.log('changeVideoSpeed')
                let playSpeedList = [-1, -0.5, 0.5, 1.0, 1.5, 2]
                let result = await $ui.menu({ items: playSpeedList })
                sender.title = playSpeedList[result.index]
                $("web-video").eval({
                    script: `video.playbackRate=${playSpeedList[result.index]}`,
                    handler: function(result, error) {
                        console.log(result)
                        console.log(error)
                    }
                })
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-close",
            title: "X",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222")
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 110)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: function(sender) {
                console.log('closeVideo')
                $("web-video").remove()
                $("web-video-speed").remove()
                $("web-video-close").remove()
                $("web-video-positon").remove()
                videoShowing[playingFolder] = false
                playingFile = null
                playingFolder = null
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-positon",
            title: "V",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222")
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 160)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: async function(sender) {
                console.log('changeVideoPosition')
                if (totalHeight <= videoHeight) {
                    return;
                }
                positionType++
                if (!position[positionType]) {
                    positionType = 0
                }
                $("web-video").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 0)
                })
                $("web-video-speed").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 60)
                })
                $("web-video-close").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 110)
                })
                $("web-video-positon").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 160)
                })
                $("web-video-positon").title = positionType != 2 ? "V" : "^"
            }
        }
    }]
}

function closeVideo() {
    if (videoShowing[playingFolder]) {
        $("web-video").remove()
        $("web-video-speed").remove()
        $("web-video-close").remove()
        $("web-video-positon").remove()
        $("web-video-menu").remove()
        videoShowing[playingFolder] = false
        playingFile = null
        playingFolder = null
    }
}

async function showVideoMenu() {
    let result = await $ui.menu({ items: ["480P", "720P", "原画", "重载", "执行js"] })
    console.log(result)
    let script = ""
    switch (result.title) {
        case "480P":
            renderVideoFile(playingFolder, playingFile, "M3U8_AUTO_480")
            break;
        case "720P":
            renderVideoFile(playingFolder, playingFile, "M3U8_AUTO_720")
            break;
        case "原画":
            break;
        case "重载":
            script = "video.load();"
            break;
        case "执行js":
            script = await $input.text({
                placeholder: "请输入js"
            })
            break;
        default:
            break;
    }
    if (script) {
        $("web-video").eval({
            script: script,
            handler: function(result, error) {
                console.log(result)
                console.log(error)
            }
        })
    }
}

function renderVideoByBDPPage(src, poster = "", containerHeight = 0, onEnd = null) {
    const html = `<body style="background: #000000;margin:0;padding:0;overflow:hidden;"><video id="video" style="width: 100vw;height: 100vh" controls="controls" src="${src}" poster="${poster}" autoplay playsinline webkit-playsinline></video></body>`
    const script = `window.video=document.getElementById("video");var touchHandle=function(){video.play();$notify("videoEvent",{"event":"touch"})};video.addEventListener("touchstart",touchHandle,true);["abort","canplay","canplaythrough","durationchange","emptied","ended","error","loadeddata","loadedmetadata","loadstart","pause","play","playing","progress","ratechange","readystatechange","seeked","seeking","stalled","suspend","timeupdate","volumechange","waiting"].forEach(function(event){video.addEventListener(event,eventHandle,false)});function eventHandle(e){$notify("videoEvent",{"event":e.type})}window.onerror=function(msg,url,line,col,error){console.log(arguments);$notify("videoEvent",{"error":arguments})};window.console.log=function(){$notify("videoEvent", Array.prototype.slice.call(arguments, 0))};$notify("videoEvent",{"event":"injectDone"});`
    // let totalHeight = $device.info.screen.height
    let totalHeight = containerHeight ? containerHeight : $device.info.screen.height - 64;
    let videoHeight = totalHeight > 256 ? 256 : totalHeight
    let position = [0, Math.round((totalHeight - videoHeight) / 2), totalHeight - videoHeight]
    let positionType = 0
    return [{
        type: "web",
        props: {
            id: "web-video",
            url: "http://pan.baidu.com/wap/welcome",
            showsProgress: false,
            hidden: true
        },
        layout: function(make, view) {
            make.left.right.equalTo(0)
            make.top.offset(position[positionType] + 0)
            make.height.equalTo(videoHeight)
        },
        events: {
            didFinish: function(sender, navigation) {
                console.log('changeView')
                sender.eval({
                    // script: `document.body.innerHTML='${html}'`,
                    script: `document.documentElement.innerHTML='${html}';${script}`,
                    handler: function(result, error) {
                        console.log(result)
                        console.log(error)
                    }
                })
            },
            videoEvent: function(params) {
                console.log(params)
                if (params.event) {
                    switch (params.event) {
                        case 'ended':
                            onEnd && onEnd()
                            break;
                        case 'error':
                            $("web-video").eval({
                                script: `$notify('videoEvent', { code: video.error.code, msg: video.error.msg })`,
                                handler: function(result, error) {
                                    console.log(result)
                                    console.log(error)
                                }
                            })
                            break;
                        case "injectDone":
                            $ui.loading(false)
                            $("web-video").hidden = false
                            $("web-video-speed").hidden = false
                            $("web-video-close").hidden = false
                            $("web-video-positon").hidden = false
                            $("web-video-menu").hidden = false
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-close",
            title: "X",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222"),
            hidden: true
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 55)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: async function(sender) {
                console.log('closeVideo')
                closeVideo()
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-speed",
            title: "1.0",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222"),
            hidden: true
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 95)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: async function(sender) {
                console.log('changeVideoSpeed')
                let playSpeedList = [0.5, 1.0, 1.5, 2]
                let result = await $ui.menu({ items: playSpeedList })
                sender.title = playSpeedList[result.index]
                $("web-video").eval({
                    script: `video.playbackRate=${playSpeedList[result.index]}`,
                    handler: function(result, error) {
                        console.log(result)
                        console.log(error)
                    }
                })
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-positon",
            title: "∇",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222"),
            hidden: true
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 135)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: async function(sender) {
                console.log('changeVideoPosition')
                if (totalHeight <= videoHeight) {
                    return;
                }
                positionType++
                if (!position[positionType]) {
                    positionType = 0
                }
                $("web-video").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 0)
                })
                $("web-video-speed").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 55)
                })
                $("web-video-close").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 95)
                })
                $("web-video-positon").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 135)
                })
                $("web-video-menu").updateLayout(function(make) {
                    make.top.offset(position[positionType] + 175)
                })
                $("web-video-positon").title = positionType != 2 ? "∇" : "∆"
            }
        }
    }, {
        type: "button",
        props: {
            id: "web-video-menu",
            title: "M",
            titleColor: $color("#dddddd"),
            bgcolor: $color("#222222"),
            hidden: true
        },
        layout: function(make, view) {
            make.top.offset(position[positionType] + 175)
            make.right.inset(10)
            make.height.equalTo(30)
            make.width.equalTo(50)
        },
        events: {
            tapped: function(sender) {
                console.log('showVideoMenu')
                showVideoMenu()
            }
        }
    }]
}

function renderFileView(path, file) {
    console.log("show file")
    console.log(file)
    switch (file.cate) {
        case 'bt':
            renderBTFile(file)
            break;
        case 'videofile':
            renderVideoFile(path, file)
            break;
        default:
            break;
    }
}

function getFileListId(path) {
    return "file-list-" + $text.MD5(path)
}

function getPageId(path) {
    return "page-view-" + $text.MD5(path)
}

function renderFileListViews(path, push = false) {
    let listId = getFileListId(path)
    videoShowing[path] = false
    let views = {
        props: {
            type: "view",
            id: getPageId(path),
            title: $l10n("BAIDU_PAN")
        },
        views: [{
                type: "button",
                props: {
                    src: "assets/file_newfolder_n_22x22_@3x.png",
                    imageEdgeInsets: $insets(5, 5, 5, 5)
                },
                layout: function(make, view) {
                    make.top.left.inset(5)
                    make.height.equalTo(40)
                    make.width.equalTo(40)
                },
                events: {
                    tapped: function(sender) {
                        console.log('showCreateFolder')
                        showCreateFolder(path)
                    }
                }
            },
            {
                type: "input",
                props: {
                    id: "search-bar",
                    type: $kbType.search,
                    darkKeyboard: true,
                    placeholder: $l10n("SEARCH")
                },
                layout: function(make, view) {
                    make.top.inset(5)
                    make.left.inset(50)
                    make.right.inset(50)
                    make.height.equalTo(40)
                },
                events: {
                    returned: function(sender) {
                        $ui.toast("待完成")
                    }
                }
            },
            {
                type: "button",
                props: {
                    src: "assets/menu_18x18_@3x.png",
                    imageEdgeInsets: $insets(5, 5, 5, 5)
                },
                layout: function(make, view) {
                    make.top.right.inset(5)
                    make.height.equalTo(40)
                    make.width.equalTo(40)
                },
                events: {
                    tapped: function(sender) {
                        console.log('showMenu')
                        showMenu(path, push)
                    }
                }
            },
            {
                type: "list",
                props: {
                    id: listId,
                    template: template.list,
                    rowHeight: 60,
                    actions: [{
                            title: "删除",
                            color: $color("red"),
                            handler: function(sender, indexPath) {
                                console.log(sender.object(indexPath))
                                console.log("showDeleteConfirm")
                                showDeleteConfirm(path, sender.object(indexPath))
                            }
                        },
                        {
                            title: "分享",
                            handler: function(sender, indexPath) {
                                console.log("showShareInput")
                                showShareInput(path, sender.object(indexPath))
                            }
                        }
                    ],
                    info: {
                        listSelectMap: {}
                    }
                },
                layout: function(make, view) {
                    make.top.equalTo($("search-bar").bottom).offset(5)
                    make.left.bottom.right.equalTo(0)
                },
                events: {
                    didSelect: function(sender, indexPath, item) {
                        if (item.isdir) {
                            closeVideo()
                            renderFileListViews(item.path, true)
                            renderFileList(item.path)
                        } else {
                            item.index = indexPath.row
                            renderFileView(path, item)
                        }
                    },
                    pulled: function(sender) {
                        renderFileList(path, true, true)
                    }
                }
            }
        ]
    }
    if (push) {
        $ui.push(views)
    } else {
        views.layout = $layout.fill
        return views
    }
}

async function renderFileList(path, refresh = false, isPulled = false) {
    let data = await getFileList(path, refresh)
    let listId = getFileListId(path)
    if (isPulled) {
        $(listId).endRefreshing()
    }
    console.log(listId)
    console.log($(listId))
    console.log("获取data")
    console.log(data)
    $(listId).data = data.map((item, key) => {
        return template.convert(item, key, BDPAN_DATA.thumbs)
    })
}

function renderMSearchViews(push = false) {
    let views = {
        props: {
            type: "view",
            id: "magnet-search",
            title: $l10n("BAIDU_PAN")
        },
        views: [{
            type: "input",
            props: {
                id: "magnet-search-input",
                type: $kbType.search,
                darkKeyboard: true,
                placeholder: $l10n("SEARCH"),
                text: mSearchWord
            },
            layout: function(make, view) {
                make.top.left.right.inset(5)
                make.height.equalTo(40)
            },
            events: {
                returned: function(sender) {
                    mSearchWord = sender.text
                    sender.blur()
                    renderMSearchResult()
                }
            }
        }, {
            type: "menu",
            props: {
                id: "magnet-search-type",
                items: MSEARCH_URLS.map((item) => item.name),
                index: 0
            },
            layout: function(make) {
                make.top.equalTo($("magnet-search-input").bottom).offset(5)
                make.left.right.equalTo(0)
                make.height.equalTo(44)
            },
            events: {
                changed: function(sender) {
                    renderMSearchResult(sender.index, 0);
                }
            }
        }, {
            type: "list",
            props: {
                id: "magnet-search-list",
                rowHeight: 60,
                template: template.mSearchList,
                actions: [{
                    title: "复制",
                    handler: function(sender, indexPath) {
                        $ui.toast("已复制")
                        $clipboard.text = sender.object(indexPath).url
                    }
                }],
                info: {
                    page: 0
                }
            },
            layout: function(make, view) {
                make.left.right.equalTo(0);
                make.top.equalTo($("magnet-search-type").bottom).offset(5)
                make.left.bottom.right.equalTo(0)
            },
            events: {
                didSelect: function(sender, indexPath, item) {
                    if (item.type == "magnet") {
                        console.log("queryMagnetInfo")
                        queryMagnetInfo(item.url)
                    } else {
                        console.log("showShareInfo")
                        showShareInfo(item.url)
                    }
                },
                pulled: function(sender) {
                    renderMSearchResult($("magnet-search-type").index, 0, true)
                },
                didReachBottom: function(sender) {
                    $ui.toast("加载中...")
                    let page = $("magnet-search-list").info.page + 1
                    renderMSearchResult($("magnet-search-type").index, page)
                }
            }
        }]
    }
    if (push) {
        $ui.push(views)
    } else {
        views.layout = $layout.fill
        return views
    }
}

async function renderMSearchResult(mType = 0, page = 1, isPulled = false) {
    if (!mSearchWord) {
        return;
    }
    let url = MSEARCH_URLS[mType].pattern.replace('__PAGE__', page) + Util.urlencode(mSearchWord)
    let data = await $BDPan.request("GET", url, { noHeaders: true })
    console.log(data);
    if (!data) {
        $ui.toast("搜索失败")
        return;
    }
    let listId = "magnet-search-list"
    if (isPulled) {
        $(listId).endRefreshing()
    }
    let prev = page ? $(listId).data : []
    if (mType == 0) {
        data = data.data.result.content
    }
    data = prev.concat(data.map((item, key) => {
        return template.convertMSearch(item, key, mType)
    }))
    console.log(data)
    $(listId).info = Util.extend({}, $(listId).info, { page: page })
    if (page) {
        $(listId).endFetchingMore()
    }
    $(listId).data = data
}

function renderMainUI(rootPath) {
    const mainUI = {
        type: "view",
        props: {
            title: "BAIDU_PAN",
            // debugging: true,
        },
        views: [{
            type: "menu",
            props: {
                id: "menu",
                items: ["网盘", "搜索", "分享"]
            },
            layout: function(make) {
                make.top.left.right.inset(0)
                make.height.equalTo(40)
            },
            events: {
                changed(sender) {
                    $device.taptic(0);
                    $("content").views.map(i => i.remove());
                    switch (sender.index) {
                        case 0:
                            $("content").add(renderFileListViews(rootPath));
                            renderFileList(rootPath)
                            break;
                        case 1:
                            $("content").add(renderMSearchViews());
                            renderMSearchResult();
                            break;
                        case 2:
                            break;
                        default:
                            break;
                    }
                }
            }
        }, {
            type: "view",
            props: {
                id: "content"
            },
            layout: function(make) {
                make.top.equalTo($("menu").bottom)
                make.left.right.bottom.inset(0)
            }
        }],
        layout: $layout.fill
    }
    $ui.render(mainUI)
    $("content").add(renderFileListViews(rootPath));
}


module.exports.render = function render() {
    renderMainUI(ROOT_PATH)
    init()
    checkVersion()
}