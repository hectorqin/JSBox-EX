const app = require('scripts/app');

app.render();