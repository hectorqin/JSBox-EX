const Util = require('scripts/util')
const FILE_CATE_LIST = {
    "txtfile": [".txt"],
    "vcard": [".vcard"],
    "videofile": [".m4v", ".wmv", ".rmvb", ".mpeg4", ".mpeg2", ".flv", ".avi", ".3gp", ".mpga", ".qt", ".rm", ".wmz", ".wmd", ".wvx", ".wmx", ".wm", ".swf", ".mpg", ".mp4", ".mkv", ".mpeg", ".mov", ".mdf", ".iso", ".asf", ".vob"],
    "html": [".html", ".js", ".css", ".vue"],
    "image": [".jpg", ".jpeg", ".gif", ".bmp", ".png", ".jpe", ".cur", ".svg", ".svgz", ".tif", ".tiff", ".ico"],
    "ipa": [".ipa"],
    "pdf": [".pdf"],
    "ppt": [".ppt", ".pptx"],
    "apk": [".apk"],
    "audiofile": [".wma", ".wav", ".mp3", ".aac", ".ra", ".ram", ".mp2", ".ogg", ".aif", ".mpega", ".amr", ".mid", ".midi", ".m4a"],
    "bt": [".torrent"],
    "compressFile": [".7z", ".a", ".ace", ".afa", ".alz", ".android", ".ar", ".arc", ".arj", ".b1", ".b1", ".ba", ".bh", ".bz2", ".cab", ".cab", ".cfs", ".chm", ".cpio", ".cpt", ".cqm", ".dar", ".dd", ".dgc", ".dmg", ".ear", ".ecc", ".eqe", ".exe", ".f", ".gca", ".gz", ".ha", ".hki", ".ice", ".id", ".infl", ".iso", ".jar", ".kgb", ".lbr", ".lha", ".lqr", ".lz", ".lzh", ".lzma", ".lzo", ".lzx", ".mar", ".ms", ".net", ".package", ".pak", ".paq6", ".paq7", ".paq8", ".par", ".par2", ".partimg", ".pea", ".pim", ".pit", ".qda", ".rar", ".rk", ".rz", ".s7z", ".sda", ".sea", ".sen", ".sfark", ".sfx", ".shar", ".sit", ".sitx", ".sqx", ".tar", ".tbz2", ".tgz", ".tlz", ".tqt", ".uc", ".uc0", ".uc2", ".uca", ".ucn", ".ue2", ".uha", ".ur2", ".war", ".web", ".wim", ".x", ".xar", ".xp3", ".xz", ".yz1", ".z", ".zip", ".zipx", ".zoo", ".zpaq", ".zz"],
    "doc": [".doc", ".docx"],
    "excel": [".xls", ".xlsx", ".csv"],
    "appfolder": [],
    "filefolder": [],
    "folder": [],
    "picturefolder": [],
    "ipadfolder": [],
    "iphonefolder": [],
    "musicfolder": [],
    "yincang": [],
    "videofolder": [],
    "visio": [],
    "unknown": []
}

let EXTENSION_TO_CATE = {}
const DEFAULT_CATE = "unknown"

for (let cate in FILE_CATE_LIST) {
    if (FILE_CATE_LIST[cate].length) {
        FILE_CATE_LIST[cate].forEach((exe) => {
            EXTENSION_TO_CATE[exe] = cate
        })
    }
}

const defaultIcon = "assets/choose_defalut_13x13_@3x.png"
const selectIcon = "assets/choose_select_14x14_@3x.png"

let list = {
    views: [{
            type: "image",
            props: {
                id: "icon-image",
                bgcolor: $color("clear")
            },
            layout: function(make, view) {
                make.left.top.bottom.inset(10)
                make.width.equalTo(view.height)
            }
        },
        {
            type: "label",
            props: {
                id: "name-label",
                font: $font(16)
            },
            layout: function(make, view) {
                make.top.inset(8)
                make.left.equalTo($("icon-image").right).offset(10)
                make.right.inset(40)
            }
        },
        {
            type: "button",
            props: {
                id: "select-button",
                src: defaultIcon,
                imageEdgeInsets: $insets(15, 15, 15, 15)
            },
            layout: function(make, view) {
                make.top.inset(10)
                make.right.inset(0)
                make.height.equalTo(40)
                make.width.equalTo(40)
            },
            events: {
                tapped: function(sender) {
                    let tableView = sender.super.super.super
                    console.log(tableView)
                    let listSelectMap = tableView.info.listSelectMap
                    let path = sender.super.get("name-label").text
                    listSelectMap[path] = listSelectMap[path] ? false : true
                    tableView.info = Util.extend({}, tableView.info, { listSelectMap: listSelectMap })
                    console.log(tableView.info)
                    let data = tableView.data
                    data[sender.info.index]["select-button"] = {
                        src: listSelectMap[path] ? selectIcon : defaultIcon,
                        info: {
                            "index": sender.info.index,
                            "select": listSelectMap[path]
                        }
                    }
                    tableView.data = data
                    let count = Object.keys(listSelectMap).reduce((sum, value) => {
                        return sum + (listSelectMap[value] ? 1 : 0)
                    }, 0)
                    tableView.super.get("select-label").text = `已选择 ${count} 项`
                }
            }
        },
        {
            type: "label",
            props: {
                id: "time-label",
                font: $font(14),
                lines: 0
            },
            layout: function(make, view) {
                make.left.equalTo($("icon-image").right).offset(10)
                make.right.inset(10)
                make.top.equalTo($("name-label").bottom).offset(5)
                make.bottom.inset(8)
            }
        },
        {
            type: "label",
            props: {
                id: "size-label",
                font: $font(14),
                lines: 0
            },
            layout: function(make, view) {
                make.right.inset(40)
                make.top.equalTo($("name-label").bottom).offset(5)
                make.bottom.inset(8)
            }
        }
    ]
}

let btList = {
    views: [{
            type: "image",
            props: {
                id: "icon-image",
                bgcolor: $color("clear")
            },
            layout: function(make, view) {
                make.left.top.bottom.inset(10)
                make.width.equalTo(view.height)
            }
        },
        {
            type: "label",
            props: {
                id: "name-label",
                font: $font(16),
                // lines: 0
            },
            layout: function(make, view) {
                make.top.equalTo(8)
                make.left.equalTo($("icon-image").right).offset(10)
                make.right.inset(40)
            }
        },
        {
            type: "button",
            props: {
                id: "select-button",
                src: defaultIcon,
                imageEdgeInsets: $insets(15, 15, 15, 15)
            },
            layout: function(make, view) {
                make.top.equalTo(10)
                make.right.inset(0)
                make.height.equalTo(40)
                make.width.equalTo(40)
            },
            events: {
                tapped: function(sender) {
                    let tableView = sender.super.super.super
                    let listSelectMap = tableView.info.listSelectMap
                    let index = sender.info.index
                    listSelectMap[index] = listSelectMap[index] ? false : true
                    tableView.info = Util.extend({}, tableView.info, { listSelectMap: listSelectMap })

                    let data = tableView.data
                    data[sender.info.index]["select-button"] = {
                        src: listSelectMap[index] ? selectIcon : defaultIcon,
                        info: {
                            "index": sender.info.index,
                            "select": listSelectMap[index]
                        }
                    }
                    tableView.data = data
                    let count = listSelectMap.reduce((sum, value) => {
                        return sum + (value ? 1 : 0)
                    }, 0)
                    tableView.super.get("select-label").text = `已选择 ${count} 项`
                }
            }
        },
        {
            type: "label",
            props: {
                id: "size-label",
                font: $font(14),
                lines: 0
            },
            layout: function(make, view) {
                make.top.equalTo($("name-label").bottom).offset(5)
                make.right.inset(40)
                make.bottom.inset(8)
            }
        }
    ]
}

let mSearchList = {
    views: [{
            type: "label",
            props: {
                id: "title-label",
                font: $font(16)
            },
            layout: function(make) {
                make.top.inset(8)
                make.left.equalTo(10)
                make.right.inset(8)
            }
        },
        {
            type: "label",
            props: {
                id: "content-label",
                textColor: $color("#888888"),
                font: $font(14)
            },
            layout: function(make) {
                make.top.equalTo($("title-label").bottom)
                make.left.equalTo(10)
                make.bottom.inset(8)
            }
        }
    ]
}

function getFileCate(path) {
    let exe = path.match(/\.[^.]*$/);
    return exe && EXTENSION_TO_CATE[exe] ? EXTENSION_TO_CATE[exe] : DEFAULT_CATE
}

function getCateIcon(cate) {
    return "assets/file_" + cate + "_icon_40x40_@3x.png";
}

function convert(item, index, thumbs = true) {
    let cate = item.isdir ? "folder" : getFileCate(item.path);
    return {
        "icon-image": {
            src: getCateIcon(cate)
        },
        "name-label": {
            text: item.server_filename
        },
        "select-button": {
            src: defaultIcon,
            info: {
                "index": index,
                "select": false
            }
        },
        "time-label": {
            text: Util.dateFormat('Y-m-d H:i', item.server_mtime) || ""
        },
        "size-label": {
            text: item.isdir ? "" : Util.renderSize(item.size)
        },
        "isdir": item.isdir,
        "path": item.path,
        "cate": cate
    }
}

function convertBT(item, index) {
    let path = item.file_name.match(/\/?([^/]*)$/)
    path = path[1]
    let cate = item.isdir ? "folder" : getFileCate(path);
    return {
        "icon-image": {
            src: getCateIcon(cate)
        },
        "name-label": {
            text: path
        },
        "select-button": {
            src: defaultIcon,
            info: {
                "index": index,
                "select": false
            }
        },
        "size-label": {
            text: Util.renderSize(item.size)
        },
        "name": path,
        "cate": cate
    }
}

function convertMSearch(item, index, mType) {
    let type = item.infohash ? "magnet" : "baidupan"
    return mType == 0 ? {
        "title-label": {
            text: item.title
        },
        "content-label": {
            text: type == "magnet" ? Util.renderSize(item.content_size) : "百度网盘"
        },
        "type": type,
        "url": type == "magnet" ? `magnet:?xt=urn:btih:${item.infohash}` : `https://pan.baidu.com/s/${item.shorturl}`
    } : {
        "title-label": {
            text: item.name
        },
        "content-label": {
            text: Util.renderSize(item.size)
        },
        "type": "magnet",
        "url": item.magnet
    }
}

module.exports = {
    list: list,
    convert: convert,
    btList: btList,
    mSearchList: mSearchList,
    convertBT: convertBT,
    convertMSearch: convertMSearch,
}