/*
* @Author: hectorqin
* @Date:   2018-05-08 15:22:20
* @Last Modified by:   hectorqin
* @Last Modified time: 2018-05-18 00:30:32
*/
const Util =  require('scripts/util.js');

const DEFAULT_HEADERS = {
    "Accept": "application/json, text/javascript, text/html, */*; q=0.01",
    "Accept-Encoding":"gzip, deflate, sdch",
    "Accept-Language":"en-US,en;q=0.8,zh-CN;q=0.6,zh;q=0.4,zh-TW;q=0.2",
    "Referer":"http://pan.baidu.com/disk/home",
    "X-Requested-With": "XMLHttpRequest",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
    "Connection": "keep-alive",
}

module.exports = class BDPan{
    constructor(cookie){
        this.cookie  = this.parseCookies(cookie)
        this.error = null
    }

    setCookie(cookie){
        this.cookie  = this.parseCookies(cookie)
    }

    getError(){
        return this.error
    }

    setError(msg){
        this.error = msg
        console.error(msg)
        return false
    }

    async getContext(){
        // var context={"loginstate":1,"username":"137*****344","third":0,"flag":1,"file_list":null,"uk":1887251485,"task_key":"4e4793ae89696f889571c563896ee6a8372e88a4","task_time":1526054618,"sampling":{"expvar":["video_high_speed","disk_timeline"]},"bdstoken":"2429ecb58418a87ef6c428c3d7fd44f2","is_vip":0,"bt_paths":null,"applystatus":1,"sign1":"8f65dc87e7ecf4a6953fc69fb3e3f540fbc3779a","sign2":"function s(j,r){var a=[];var p=[];var o=\"\";var v=j.length;for(var q=0;q<256;q++){a[q]=j.substr((q%v),1).charCodeAt(0);p[q]=q}for(var u=q=0;q<256;q++){u=(u+p[q]+a[q])%256;var t=p[q];p[q]=p[u];p[u]=t}for(var i=u=q=0;q<r.length;q++){i=(i+1)%256;u=(u+p[i])%256;var t=p[i];p[i]=p[u];p[u]=t;k=p[((p[i]+p[u])%256)];o+=String.fromCharCode(r.charCodeAt(q)^k)}return o};","sign3":"6556e16d6c8abba7071389adc782706b","timestamp":1526054618,"timeline_status":1,"face_status":1,"srv_ts":1526054618,"need_tips":null,"is_year_vip":0,"show_vip_ad":0,"vip_end_time":null,"is_evip":0,"is_svip":0,"is_auto_svip":0,"activity_status":0,"photo":"https:\/\/ss0.bdstatic.com\/7Ls0a8Sm1A5BphGlnYG\/sys\/portrait\/item\/6270c279.jpg","curr_activity_code":0,"activity_end_time":0,"token":"81738DTmXCvT0grF79L14AV05EUkzLoYu0H+2IHA42Nkdzt86iRylmoNptvhzO+bzfUIcYGGEpqOP1K2x3TGsRjlUgErmdrRfyrBatzMWEp2gvqreR2I5XQ3YNW57skRXFun4JHA2LSXz3X08DIEagG9PsrX\/59YE7HLphDGANUy68dE+Luv50BHPMgF\/fhzmRc5evGBE2Vp\/jc06hgZOVkhXU0UqtriB4fhQ1pHZ6Q2SkNkSWLyhpMMcw3zMwup6vcucNdf7X7Nfhok2X1oGkVf9FxAlMd5lw3Olreb","sharedir":0,"pansuk":"v8WC8_yw7oLDu3eM1yS3Dg","skinName":"black","urlparam":[],"XDUSS":"pansec_DCb740ccc5511e5e8fedcff06b081203-Zc%2FnJmIvcoED8BYcWsdp3DpH3ZyXEid9Kae5Ysa08NZoTjdzd5jgYGUeEjg%2B26HLKD7wvv%2Fl9Sq6OpqZnhKHl%2FrgaZH316%2Fl6QV2HW6jQodkN7Y9mDtgJpBL9ywlevlqgKna4you1P4RDnPwzzTgFOKg%2FgheScjavSYXevZa3OMGTAKba0l6G7%2FTM%2FnpS98navJzjnHsILU3DJYobEQHcY2Kk27SqzWpu1cYHNVUSkfmFmcWhkPH3RBDuhjZXbYgHe3Er%2BKuDHdu6rXouEmH6A%3D%3D"};
        let data = await this.request('GET', 'http://pan.baidu.com/disk/home')
        let result = data.match(/var context=(.*)/)
        // console.log(result)
        if(result && result.length){
            this.context = JSON.parse(result[1])
            return this.context
        }else{
            return this.setError('Can\'t get context')
        }
    }

    async getBdstoken(){
        if(this.context.bdstoken){
            return this.context.bdstoken
        }
        let data = await this.request('GET', 'http://pan.baidu.com/disk/home')

        let result = data.match(/"bdstoken":"(.+?)"/)
        if(result.length){
            return result[1]
        }else{
            return this.setError('Can\'t get bdstoken')
        }
    }

    getPath(url){
        let result = url.match(/path=(.+?)(&|$)/)
        if(result.length){
            return Util.urldecode(result[1])
        }else{
            return url
        }
    }

    async getQuota(){
        const url = 'http://pan.baidu.com/api/quota'
        let data = await this.request('GET', url)
        if(!data || data['errno'] != 0){
            return this.setError('Error at getQuota')
        }
        return data
    }

    async getFileList(dir_="/", desc=true, order="name", num=100, all=true){
        const timestamp = new Date().getTime()
        let params = {
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "showempty": 1,
            "num": num,   // max amount is 10000
            "t": timestamp,
            "dir": dir_,
            "page": 1,
            "desc": 1,   // reversely
            "order": order, // sort by name, or size, time
            "_": timestamp,
            // "bdstoken": this.getBdstoken(),
        }
        if(!desc){
            delete params['desc']
        }

        let pathList = []
        let data = null
        let url = ''
        while(true){
            url = Util.addParamsToUrl('http://pan.baidu.com/api/list', params)
            data = await this.request('GET', url)
            if( data['errno'] != 0 ){
                return this.setError('Error at getFileList')
            }

            if(!all){
                return data
            }
            pathList = pathList.concat(data['list'])

            if( data['list'].length == num ){
                params['page'] += 1
            }else{
                data['list'] = pathList
                return data
            }
        }
    }

    async searchFileList(dir_="/", desc=true, order="name", num=100, all=true){
        const timestamp = new Date().getTime()
        let params = {
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "showempty": 0,
            "num": num,   // max amount is 10000
            "t": timestamp,
            "dir": dir_,
            "page": 1,
            "desc": 1,   // reversely
            "order": order, // sort by name, or size, time
            "_": timestamp,
            // "bdstoken": this.getBdstoken(),
        }
        if(!desc){
            delete params['desc']
        }

        let pathList = []
        let data = null
        let url = ''
        while(true){
            url = Util.addParamsToUrl('http://pan.baidu.com/api/list', params)
            data = await this.request('GET', url)
            if( data['errno'] != 0 ){
                return this.setError('Error at getFileList')
            }

            if(!all){
                return data
            }
            pathList = pathList.concat(data['list'])

            if( data['list'].length == num ){
                params['page'] += 1
            }else{
                data['list'] = pathList
                return data
            }
        }
    }

    async meta(fileList){
        fileList = Util.isArray(fileList) ? fileList : [fileList]
        const params = {
            "channel": "chunlei",
            "app_id": 250528,
            "dlink": 1,
            "clienttype": 0,
            "web": 1,
            "bdstoken": await this.getBdstoken()
        }

        const url = Util.addParamsToUrl('http://pan.baidu.com/api/filemetas', params)
        let i = 0
        let j = {}
        let fl = false
        let result = null
        while(true){
            fl = fileList.slice(i, i+100)
            console.log("fl")
            console.log(fl)
            if(fl.length){
                result = await this.request('GET', url + "&target=" + Util.urlencode(JSON.stringify(fl)))
                if( result && result['errno'] == 0){
                    if(i == 0){
                        j = result
                    }else{
                        j['info'].push(result['info'])
                    }
                }else{
                    return j['info'].push(null)
                }
            }else{
                return j
            }
            i += 100
        }
    }

    async getDsign(){
        let data = await this.request('GET', 'http://pan.baidu.com/disk/home')
        let sign1 = data.match(/"sign1":"(.+?)"/)
        let sign3 = data.match(/"sign3":"(.+?)"/)
        let timestamp = data.match(/"timestamp":(\d+)/)
        let bdstoken = data.match(/"bdstoken":"(.+?)"/)
        if(!sign1.length || !sign3.length || !timestamp.length || !bdstoken.length){
            return [ false, false ]
        }

        // function sign2(j,r){var a=[];var p=[];var o="";var v=j.length;for(var q=0;q<256;q++){a[q]=j.substr((q%v),1).charCodeAt(0);p[q]=q}for(var u=q=0;q<256;q++){u=(u+p[q]+a[q])%256;var t=p[q];p[q]=p[u];p[u]=t}for(var i=u=q=0;q<r.length;q++){i=(i+1)%256;u=(u+p[i])%256;var t=p[i];p[i]=p[u];p[u]=t;k=p[((p[i]+p[u])%256)];o+=String.fromCharCode(r.charCodeAt(q)^k)}return o};
        function sign2(j, r) {
            let a = [];
            let p = [];
            let o = "";
            let v = j.length;
            let k,t,q,u
            for (let q = 0; q < 256; q++) {
                a[q] = j.substr((q % v), 1).charCodeAt(0);
                p[q] = q
            }
            for (let u = q = 0; q < 256; q++) {
                u = (u + p[q] + a[q]) % 256;
                t = p[q];
                p[q] = p[u];
                p[u] = t
            }
            for (let i = u = q = 0; q < r.length; q++) {
                i = (i + 1) % 256;
                u = (u + p[i]) % 256;
                t = p[i];
                p[i] = p[u];
                p[u] = t;
                k = p[((p[i] + p[u]) % 256)];
                o += String.fromCharCode(r.charCodeAt(q) ^ k)
            }
            return o
        }
        return [ sign2(sign3[1], sign1[1]), timestamp[1], bdstoken[1] ]
    }

    getDLink2(path){
        let dlink = `http://c.pcs.baidu.com/rest/2.0/pcs/file?method=download'
                 '&app_id=250528&path=${Util.urlencode(path)}&ver=2.0&clienttype=1`

        // dlink = fast_pcs_server(dlink)
        return dlink
    }

    async getDlink(fs_id){
        let [ dsign, timestamp, bdstoken ] = await this.getDsign()
        if(!dsign || !timestamp){
            return this.setError('Error at getDlink2')
        }
        console.log(dsign, timestamp)
        let params = {
            "channel": "chunlei",
            "clienttype": 0,
            "app_id": "250528",
            "web": 1,
            "bdstoken": bdstoken,
            "sign": dsign,
            "timestamp": timestamp,
            "fidlist": `[${fs_id}]`,
            "type": "dlink",
        }

        const url = Util.addParamsToUrl('http://pan.baidu.com/api/download', params)
        let result = await this.request('GET', url)
        if( result['errno'] == 0 ){
            let dlink = result['dlink'][0]['dlink']
            // # dlink = re.sub(r'prisign=.+?(&|$)', r'prisign=unknow\1', dlink)
            // # dlink = dlink.replace('chkbd=0', 'chkbd=1')
            // # dlink = dlink.replace('chkv=0', 'chkv=1')
            // dlink = fast_pcs_server(dlink)
            return dlink
        }else{
            return this.setError('Error at getDlink2')
        }
    }

    async getM3u8(path, getFile=false, type="M3U8_AUTO_480"){
        if(type!="M3U8_AUTO_720" && type!="M3U8_AUTO_480"){
            type="M3U8_AUTO_720"
        }
        let params = {
            "method": "streaming",
            "path": path,
            "type": type,
            "app_id": "250528",
            "bdstoken": await this.getBdstoken(),
        }

        let url = Util.addParamsToUrl('https://pcs.baidu.com/rest/2.0/pcs/file', params)
        if(!getFile) return url;
        let result = await this.request('GET', url)
        console.log(result)
        return result
    }

    async mkdir(dir_){
        let params = {
            "a": "commit",
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "app_id": "250528",
            "bdstoken": await this.getBdstoken()
        }
        let body = {
            "path": dir_,
            "isdir": 1,
            "block_list": []
        }
        let url = Util.addParamsToUrl('http://pan.baidu.com/api/create', params)
        let data = await this.request('POST', url, {
            'body': body,
            'header': {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })

        if(data['errno']!=0){
            return this.setError('Error at mkdir')
        }else{
            return true
        }
    }

    async _exist(list_){
        let meta = await this.meta(list_)
        if(meta){
            return true
        }else{
            return false
        }
    }

    async filemanager(opera, data, callback){
        let params = {
            "channel": "chunlei",
            "clienttype": 0,
            "onnest": "fail",
            "web": 1,
            "async": 2,
            "opera": opera,
            "app_id": 250528,
            "bdstoken": await this.getBdstoken(),
        }
        let url = Util.addParamsToUrl('http://pan.baidu.com/api/filemanager', params)
        let result = await this.request('POST', url, {
            'body': data,
            'header': {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })
        console.log(result)
        if( result['errno'] == 0) {
            this.taskQueryTimer(result['taskid'], data, callback)
            return true
        }else if(result['errno'] == 12 ){
            return this.setError('Error at filemanager: some file exists')
        }else{
            return this.setError('Error at filemanager')
        }
    }

    async move(paths, remotepath){
        paths = Util.isArray(paths) ? paths : [paths]
        let meta = await this.meta([remotepath])
        if(!meta){
            await this.mkdir(remotepath)
        }else if(!meta['info'][0]['isdir']){
            return this.setError(`Error at move, ${remotepath} is a file`)
        }
        let list = []
        paths.forEach((path)=>{
            list.push({
                'path': path,
                'dest': remotepath,
                'newname': Util.pathinfo(path, 'PATHINFO_BASENAME')
            })
        })

        const data = {
            'filelist': Util.urlencode(JSON.stringify(list))
        }
        return await this.filemanager('move', data)
    }

    async copy(paths, remotepath){
        paths = Util.isArray(paths) ? paths : [paths]
        let meta = await this.meta([remotepath])
        if(!meta){
            await this.mkdir(remotepath)
        }else if(!meta['info'][0]['isdir']){
            return this.setError(`Error at move, ${remotepath} is a file`)
        }
        let list = []
        if(paths.length == 1){
            list.push({
                'path': path,
                'dest': Util.pathinfo(remotepath, 'PATHINFO_DIRNAME'),
                'newname': Util.pathinfo(remotepath, 'PATHINFO_BASENAME')
            })
        }else{
            paths.forEach((path)=>{
                list.push({
                    'path': path,
                    'dest': remotepath,
                    'newname': Util.pathinfo(path, 'PATHINFO_BASENAME')
                })
            })
        }

        const data = {
            'filelist': Util.urlencode(JSON.stringify(list))
        }
        return await this.filemanager('copy', data)
    }

    taskQueryTimer(taskId, data, callback){
        let times = 0
        let maxTimes = 10
        let timer = $timer.schedule({
            interval: 1,
            handler: () => {
                this.taskQuery(taskId, data).then((data)=>{
                    if(data){
                        timer.invalidate()
                        callback && callback()
                    }
                    if(times > maxTimes){
                        $ui.toast("任务查询超时")
                        timer.invalidate()
                    }
                    times++
                })
            }
        })
    }

    async taskQuery(taskId, data){
        let params = {
            "taskid": taskId,
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "app_id": 250528,
            "bdstoken": await this.getBdstoken(),
        }
        let url = Util.addParamsToUrl('http://pan.baidu.com/share/taskquery', params)
        let result = await this.request('POST', url, {
            'body': data,
            'header': {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })
        console.log(result)
        if( result['errno'] == 0 && result["status"]=="success") {
            return result
        }else{
            return this.setError('Error at taskQuery')
        }
    }

    async remove(paths, callback){
        let list = Util.isArray(paths) ? paths : [paths]

        const data = {
            'filelist': JSON.stringify(list)
        }
        return await this.filemanager('delete', data, callback)
    }

    async rename(path, remotepath){
        let meta = await this.meta([remotepath])
        if(meta){
            return this.setError(`Error at rename, ${remotepath} is existed`)
        }
        let { dirname, basename } = Util.pathinfo(remotepath)

        meta = this.meta([dirname])
        if(!meta){
            await this.mkdir(dirname)
        }else if(!meta['info'][0]['isdir']){
            return this.setError(`Error at move, ${dirname} is a file`)
        }

        let list = [{
            'path': path,
            'dest': dirname,
            'newname': basename
        }]
        const data = 'filelist=' + Util.urlencode(JSON.stringify(list))
        return await this.filemanager('move', data)
    }

    async getTorrentInfo(path){
        let params = {
            "bdstoken": this.getBdstoken(),
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "app_id": 250528,
            "method": "query_sinfo",
            "source_path": path,
            "type": 2,
            "t": new Date().getTime(),
        }

        let url = Util.addParamsToUrl('http://pan.baidu.com/rest/2.0/services/cloud_dl', params)
        let result = await this.request('GET', url)
        if(result.error_code){
            return this.setError('Error at getTorrentInfo:' + result['error_msg'])
        }else{
            return result['torrent_info']
        }
    }

    async getMagnetInfo(url){
        let params = {
            "bdstoken": this.getBdstoken(),
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "app_id": 250528,
        }
        let data = {
            "method": "query_magnetinfo",
            "app_id": 250528,
            "source_url": url,
            "save_path": "/",
            "type": 4,
        }
        let apiUrl = Util.addParamsToUrl('http://pan.baidu.com/rest/2.0/services/cloud_dl', params)
        let result = await this.request('POST', apiUrl, {
            'body': data,
            'header': {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })
        if(result.error_code){
            return this.setError('Error at getMagnetInfo:' + result['error_msg'])
        }else{
            return result['magnet_info']
        }
    }

    async downloadBT(url, ssh1, idList, remotepath){
        let params = {
            "bdstoken": this.getBdstoken(),
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "app_id": 250528,
        }
        let body = {
            "method": "add_task",
            "app_id": 250528,
            "file_sha1": ssh1,
            "save_path": remotepath,
            "selected_idx": idList.join(","),
            "task_from": 1,
            "t": new Date().getTime(),
        }
        if(url.indexOf('magnet:')!=-1){
            body['source_url'] = url
            body['type'] = 4
        }else{
            body['source_path'] = url
            body['type'] = 2
        }
        while(true){
            let url = Util.addParamsToUrl('http://pan.baidu.com/rest/2.0/services/cloud_dl', params)
            let result = await this.request('POST', url, {
                'body': body,
                'header': {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            })
            if (result['error_code'] == -19) {
                return this.setError('请输入验证码')
            }else if(result['error_code'] && result['error_code'] != -19){
                return this.setError('Error at downloadBT:' + result['error_msg'])
            }
            return result
        }
    }

    async share(paths, pwd){
        let meta = await this.meta(paths)
        let fs_ids = meta.info.map((item)=>{
            return item['fs_id'];
        })

        let params = {
            'app_id': 250528,
            'channel': 'chunlei',
            'clienttype': 0,
            'web': 1,
            "bdstoken": await this.getBdstoken()
        }
        let body={}

        if(pwd){
            body = {
                'fid_list': JSON.stringify(fs_ids),
                'schannel': 4,
                'channel_list': '[]',
                'pwd': pwd,
                'period': 0
            }
        }else{
            body = {
                'fid_list': JSON.stringify(fs_ids),
                'schannel': 0,
                'channel_list': '[]',
                'period': 0
            }
        }

        let url = Util.addParamsToUrl('http://pan.baidu.com/share/set', params)
        let result = await this.request('POST', url, {
            'body': body,
            'header': {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })

        if(result['errno']!=0){
            return this.setError('Error at share');
        }else{
            return result;
        }
    }

    async getShareInfo(url){
        let html = await this.request("GET", url)
        let result = html.match(/yunData.setData\((.+?)\);/)
        let info = {}
        if(result && result.length){
            return JSON.parse(result[1])
        }else{
            return this.setError('Error at getShareInfo:' + url)
        }
    }

    async getShareFileList(uk, shareid, dir, all=true, num=100, order="other"){
        // https://pan.baidu.com/share/list?uk=1887251485&shareid=3583580685&order=other&desc=1&showempty=0&web=1&page=1&num=100&dir=/学习/源码/【小程序源码】/1：小程序源码&t=0.8089842252635997&channel=chunlei&web=1&app_id=250528&bdstoken=null&logid=MTUyNjM4ODYyNDA5ODAuOTA2NjkxMTcyNTQzMzYwNg==&clienttype=0
        const timestamp = new Date().getTime()
        let params = {
            'app_id': 250528,
            "channel": "chunlei",
            "clienttype": 0,
            "web": 1,
            "showempty": 1,
            "uk": uk,
            "shareid": shareid,
            "num": num,   // max amount is 10000
            "t": timestamp,
            "dir": dir,
            "page": 1,
            "desc": 1,   // reversely
            "order": order, // sort by name, or size, time
            "bdstoken": "null"
            // "bdstoken": this.getBdstoken(),
        }

        let fileList = []
        let data = null
        let url = ''
        while(true){
            url = Util.addParamsToUrl('http://pan.baidu.com/share/list', params)
            data = await this.request('GET', url)
            if( data['errno'] != 0 ){
                return this.setError('Error at getShareFileList')
            }

            if(!all){
                return data
            }
            fileList = fileList.concat(data['list'])

            if( data['list'].length == num ){
                params['page'] += 1
            }else{
                data['list'] = fileList
                return data
            }
        }
    }

    parseCookies(cookie){
        let cookies = {}
        let k,v
        cookie.split('; ').forEach((c)=>{
            [ k, v ] = c.split('=')
            cookies[k] = v
        })
        return cookies
    }
    getCookies(){
        return this.cookie
    }
    saveCookies(cookieString){
        console.log(cookieString)
        this.cookie = Util.extend({}, this.getCookies(), this.parseCookies(cookieString) )
    }
    cookieStringify(cookie){
        let string = ''
        for( let k in cookie){
            string += k + '=' + cookie[k] + '; '
        }
        return string
    }
    getHeaders(header){
        header = header || {}
        let cookie = {
            'Cookie': this.cookieStringify(Util.extend({}, this.getCookies(), header['Cookie'] || {} ))
        }
        delete header['Cookie']
        return Util.extend({}, DEFAULT_HEADERS, header || {}, cookie)
    }
    async request(method, url, params){
        params = params || {}
        let t = 0
        let h = !params && !params.noHeaders ? this.getHeaders(params['header'] || {}) : {}
        console.log("header")
        console.log(h)
        while(t<3){
            t++
            let resp = await $http.request({
                method: method,
                url: url,
                header: h,
                body: params['body']
            })
            console.log(method + " " + url)
            console.log(params)
            console.log(resp.response)
            console.log(resp.data)
            if(resp.response.statusCode != 200){
                continue
            }
            const headers = resp.response.headers
            headers['Set-Cookie'] && this.saveCookies(headers['Set-Cookie'])
            return resp.data
        }
    }
}