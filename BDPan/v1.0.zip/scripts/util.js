/*
    ## Utilities
*/
var Util = {}

Util.extend = function extend() {
    var target = arguments[0] || {},
        i = 1,
        length = arguments.length,
        options, name, src, copy, clone

    if (length === 1) {
        target = this
        i = 0
    }

    for (; i < length; i++) {
        options = arguments[i]
        if (!options) continue

        for (name in options) {
            src = target[name]
            copy = options[name]

            if (target === copy) continue
            if (copy === undefined) continue

            if (Util.isArray(copy) || Util.isObject(copy)) {
                if (Util.isArray(copy)) clone = src && Util.isArray(src) ? src : []
                if (Util.isObject(copy)) clone = src && Util.isObject(src) ? src : {}

                target[name] = Util.extend(clone, copy)
            } else {
                target[name] = copy
            }
        }
    }

    return target
}

Util.each = function each(obj, iterator, context) {
    var i, key
    if (this.type(obj) === 'number') {
        for (i = 0; i < obj; i++) {
            iterator(i, i)
        }
    } else if (obj.length === +obj.length) {
        for (i = 0; i < obj.length; i++) {
            if (iterator.call(context, obj[i], i, obj) === false) break
        }
    } else {
        for (key in obj) {
            if (iterator.call(context, obj[key], key, obj) === false) break
        }
    }
}

Util.type = function type(obj) {
    return (obj === null || obj === undefined) ? String(obj) : Object.prototype.toString.call(obj).match(/\[object (\w+)\]/)[1].toLowerCase()
}

Util.each('String Object Array RegExp Function'.split(' '), function(value) {
    Util['is' + value] = function(obj) {
        return Util.type(obj) === value.toLowerCase()
    }
})

Util.isObjectOrArray = function(value) {
    return Util.isObject(value) || Util.isArray(value)
}

Util.isNumeric = function(value) {
    return !isNaN(parseFloat(value)) && isFinite(value)
}

Util.keys = function(obj) {
    var keys = [];
    for (var key in obj) {
        if (obj.hasOwnProperty(key)) keys.push(key)
    }
    return keys;
}
Util.values = function(obj) {
    var values = [];
    for (var key in obj) {
        if (obj.hasOwnProperty(key)) values.push(obj[key])
    }
    return values;
}

Util.noop = function() {}

Util.addParamsToUrl = function(url, params) {
    var sep = url.indexOf("?") >= 0 ? "&" : "?";
    return url + sep + Util.http_build_query(params);
}
Util.urlencode = function(str) {
    str = (str + '');
    return encodeURIComponent(str)
        .replace(/!/g, '%21')
        .replace(/'/g, '%27')
        .replace(/\(/g, '%28')
        .replace(/\)/g, '%29')
        .replace(/\*/g, '%2A')
        .replace(/%20/g, '+');
}

Util.urldecode = function(str) {
    return decodeURIComponent((str + '')
        .replace(/%(?![\da-f]{2})/gi, function() {
            // PHP tolerates poorly formed escape sequences
            return '%25'
        })
        .replace(/\+/g, '%20'))
}
Util.http_build_query = function(formdata, numeric_prefix, arg_separator) {
    var value, key, tmp = [];
    var _http_build_query_helper = function(key, val, arg_separator) {
        var k, tmp = [];
        if (val === true) {
            val = '1';
        } else if (val === false) {
            val = '0';
        }
        if (val != null) {
            if (typeof val === 'object') {
                for (k in val) {
                    if (val[k] != null) {
                        tmp.push(_http_build_query_helper(key + '[' + k + ']', val[k], arg_separator));
                    }
                }
                return tmp.join(arg_separator);
            } else if (typeof val !== 'function') {
                return Util.urlencode(key) + '=' + Util.urlencode(val);
            } else {
                throw new Error('There was an error processing for http_build_query().');
            }
        } else {
            return '';
        }
    };

    if (!arg_separator) {
        arg_separator = '&';
    }
    for (key in formdata) {
        value = formdata[key];
        if (numeric_prefix && !isNaN(key)) {
            key = String(numeric_prefix) + key;
        }
        var query = _http_build_query_helper(key, value, arg_separator);
        if (query !== '') {
            tmp.push(query);
        }
    }

    return tmp.join(arg_separator);
};

Util.tryCatch = function(func, errorHandle) {
    try {
        Util.isFunction(func) && func()
    } catch (e) {
        Util.isFunction(errorHandle) && errorHandle(e)
    }
}

Util.basename = function(path, suffix) {
    //  discuss at: http://locutus.io/php/basename/
    // original by: Kevin van Zonneveld (http://kvz.io)
    // improved by: Ash Searle (http://hexmen.com/blog/)
    // improved by: Lincoln Ramsay
    // improved by: djmix
    // improved by: Dmitry Gorelenkov
    //   example 1: basename('/www/site/home.htm', '.htm')
    //   returns 1: 'home'
    //   example 2: basename('ecra.php?p=1')
    //   returns 2: 'ecra.php?p=1'
    //   example 3: basename('/some/path/')
    //   returns 3: 'path'
    //   example 4: basename('/some/path_ext.ext/','.ext')
    //   returns 4: 'path_ext'

    var b = path
    var lastChar = b.charAt(b.length - 1)

    if (lastChar === '/' || lastChar === '\\') {
        b = b.slice(0, -1)
    }

    b = b.replace(/^.*[/\\]/g, '')

    if (typeof suffix === 'string' && b.substr(b.length - suffix.length) === suffix) {
        b = b.substr(0, b.length - suffix.length)
    }

    return b
}

Util.pathinfo = function(path, options) {
    //  discuss at: http://locutus.io/php/pathinfo/
    // original by: Nate
    //  revised by: Kevin van Zonneveld (http://kvz.io)
    // improved by: Brett Zamir (http://brett-zamir.me)
    // improved by: Dmitry Gorelenkov
    //    input by: Timo
    //      note 1: Inspired by actual PHP source: php5-5.2.6/ext/standard/string.c line #1559
    //      note 1: The way the bitwise arguments are handled allows for greater flexibility
    //      note 1: & compatability. We might even standardize this
    //      note 1: code and use a similar approach for
    //      note 1: other bitwise PHP functions
    //      note 1: Locutus tries very hard to stay away from a core.js
    //      note 1: file with global dependencies, because we like
    //      note 1: that you can just take a couple of functions and be on your way.
    //      note 1: But by way we implemented this function,
    //      note 1: if you want you can still declare the PATHINFO_*
    //      note 1: yourself, and then you can use:
    //      note 1: pathinfo('/www/index.html', PATHINFO_BASENAME | PATHINFO_EXTENSION);
    //      note 1: which makes it fully compliant with PHP syntax.
    //   example 1: pathinfo('/www/htdocs/index.html', 1)
    //   returns 1: '/www/htdocs'
    //   example 2: pathinfo('/www/htdocs/index.html', 'PATHINFO_BASENAME')
    //   returns 2: 'index.html'
    //   example 3: pathinfo('/www/htdocs/index.html', 'PATHINFO_EXTENSION')
    //   returns 3: 'html'
    //   example 4: pathinfo('/www/htdocs/index.html', 'PATHINFO_FILENAME')
    //   returns 4: 'index'
    //   example 5: pathinfo('/www/htdocs/index.html', 2 | 4)
    //   returns 5: {basename: 'index.html', extension: 'html'}
    //   example 6: pathinfo('/www/htdocs/index.html', 'PATHINFO_ALL')
    //   returns 6: {dirname: '/www/htdocs', basename: 'index.html', extension: 'html', filename: 'index'}
    //   example 7: pathinfo('/www/htdocs/index.html')
    //   returns 7: {dirname: '/www/htdocs', basename: 'index.html', extension: 'html', filename: 'index'}

    var basename = Util.basename
    var opt = ''
    var realOpt = ''
    var optName = ''
    var optTemp = 0
    var tmpArr = {}
    var cnt = 0
    var i = 0
    var haveBasename = false
    var haveExtension = false
    var haveFilename = false

    // Input defaulting & sanitation
    if (!path) {
        return false
    }
    if (!options) {
        options = 'PATHINFO_ALL'
    }

    // Initialize binary arguments. Both the string & integer (constant) input is
    // allowed
    var OPTS = {
        'PATHINFO_DIRNAME': 1,
        'PATHINFO_BASENAME': 2,
        'PATHINFO_EXTENSION': 4,
        'PATHINFO_FILENAME': 8,
        'PATHINFO_ALL': 0
    }
    // PATHINFO_ALL sums up all previously defined PATHINFOs (could just pre-calculate)
    for (optName in OPTS) {
        if (OPTS.hasOwnProperty(optName)) {
            OPTS.PATHINFO_ALL = OPTS.PATHINFO_ALL | OPTS[optName]
        }
    }
    if (typeof options !== 'number') {
        // Allow for a single string or an array of string flags
        options = [].concat(options)
        for (i = 0; i < options.length; i++) {
            // Resolve string input to bitwise e.g. 'PATHINFO_EXTENSION' becomes 4
            if (OPTS[options[i]]) {
                optTemp = optTemp | OPTS[options[i]]
            }
        }
        options = optTemp
    }

    // Internal Functions
    var _getExt = function(path) {
        var str = path + ''
        var dotP = str.lastIndexOf('.') + 1
        return !dotP ? false : dotP !== str.length ? str.substr(dotP) : ''
    }

    // Gather path infos
    if (options & OPTS.PATHINFO_DIRNAME) {
        var dirName = path
            .replace(/\\/g, '/')
            .replace(/\/[^/]*\/?$/, '') // dirname
        tmpArr.dirname = dirName === path ? '.' : dirName
    }

    if (options & OPTS.PATHINFO_BASENAME) {
        if (haveBasename === false) {
            haveBasename = basename(path)
        }
        tmpArr.basename = haveBasename
    }

    if (options & OPTS.PATHINFO_EXTENSION) {
        if (haveBasename === false) {
            haveBasename = basename(path)
        }
        if (haveExtension === false) {
            haveExtension = _getExt(haveBasename)
        }
        if (haveExtension !== false) {
            tmpArr.extension = haveExtension
        }
    }

    if (options & OPTS.PATHINFO_FILENAME) {
        if (haveBasename === false) {
            haveBasename = basename(path)
        }
        if (haveExtension === false) {
            haveExtension = _getExt(haveBasename)
        }
        if (haveFilename === false) {
            haveFilename = haveBasename.slice(0, haveBasename.length - (haveExtension ?
                haveExtension.length + 1 :
                haveExtension === false ?
                0 :
                1
            ))
        }

        tmpArr.filename = haveFilename
    }

    // If array contains only 1 element: return string
    cnt = 0
    for (opt in tmpArr) {
        if (tmpArr.hasOwnProperty(opt)) {
            cnt++
            realOpt = opt
        }
    }
    if (cnt === 1) {
        return tmpArr[realOpt]
    }

    // Return full-blown array
    return tmpArr
}

Util.dateFormat = function(format, timestamp) {
    var jsdate, f
    // Keep this here (works, but for code commented-out below for file size reasons)
    // var tal= [];
    var txtWords = [
        'Sun', 'Mon', 'Tues', 'Wednes', 'Thurs', 'Fri', 'Satur',
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ]
    // trailing backslash -> (dropped)
    // a backslash followed by any character (including backslash) -> the character
    // empty string -> empty string
    var formatChr = /\\?(.?)/gi
    var formatChrCb = function(t, s) {
        return f[t] ? f[t]() : s
    }
    var _pad = function(n, c) {
        n = String(n)
        while (n.length < c) {
            n = '0' + n
        }
        return n
    }

    f = {
        // Day
        d: function() {
            // Day of month w/leading 0; 01..31
            return _pad(f.j(), 2)
        },
        D: function() {
            // Shorthand day name; Mon...Sun
            return f.l()
                .slice(0, 3)
        },
        j: function() {
            // Day of month; 1..31
            return jsdate.getDate()
        },
        l: function() {
            // Full day name; Monday...Sunday
            return txtWords[f.w()] + 'day'
        },
        N: function() {
            // ISO-8601 day of week; 1[Mon]..7[Sun]
            return f.w() || 7
        },
        S: function() {
            // Ordinal suffix for day of month; st, nd, rd, th
            var j = f.j()
            var i = j % 10
            if (i <= 3 && parseInt((j % 100) / 10, 10) === 1) {
                i = 0
            }
            return ['st', 'nd', 'rd'][i - 1] || 'th'
        },
        w: function() {
            // Day of week; 0[Sun]..6[Sat]
            return jsdate.getDay()
        },
        z: function() {
            // Day of year; 0..365
            var a = new Date(f.Y(), f.n() - 1, f.j())
            var b = new Date(f.Y(), 0, 1)
            return Math.round((a - b) / 864e5)
        },

        // Week
        W: function() {
            // ISO-8601 week number
            var a = new Date(f.Y(), f.n() - 1, f.j() - f.N() + 3)
            var b = new Date(a.getFullYear(), 0, 4)
            return _pad(1 + Math.round((a - b) / 864e5 / 7), 2)
        },

        // Month
        F: function() {
            // Full month name; January...December
            return txtWords[6 + f.n()]
        },
        m: function() {
            // Month w/leading 0; 01...12
            return _pad(f.n(), 2)
        },
        M: function() {
            // Shorthand month name; Jan...Dec
            return f.F()
                .slice(0, 3)
        },
        n: function() {
            // Month; 1...12
            return jsdate.getMonth() + 1
        },
        t: function() {
            // Days in month; 28...31
            return (new Date(f.Y(), f.n(), 0))
                .getDate()
        },

        // Year
        L: function() {
            // Is leap year?; 0 or 1
            var j = f.Y()
            return j % 4 === 0 & j % 100 !== 0 | j % 400 === 0
        },
        o: function() {
            // ISO-8601 year
            var n = f.n()
            var W = f.W()
            var Y = f.Y()
            return Y + (n === 12 && W < 9 ? 1 : n === 1 && W > 9 ? -1 : 0)
        },
        Y: function() {
            // Full year; e.g. 1980...2010
            return jsdate.getFullYear()
        },
        y: function() {
            // Last two digits of year; 00...99
            return f.Y()
                .toString()
                .slice(-2)
        },

        // Time
        a: function() {
            // am or pm
            return jsdate.getHours() > 11 ? 'pm' : 'am'
        },
        b: function() {
            // 上午 or 下午
            return jsdate.getHours() > 11 ? '下午' : '上午'
        },
        A: function() {
            // AM or PM
            return f.a()
                .toUpperCase()
        },
        B: function() {
            // Swatch Internet time; 000..999
            var H = jsdate.getUTCHours() * 36e2
            // Hours
            var i = jsdate.getUTCMinutes() * 60
            // Minutes
            // Seconds
            var s = jsdate.getUTCSeconds()
            return _pad(Math.floor((H + i + s + 36e2) / 86.4) % 1e3, 3)
        },
        g: function() {
            // 12-Hours; 1..12
            return f.G() % 12 || 12
        },
        G: function() {
            // 24-Hours; 0..23
            return jsdate.getHours()
        },
        h: function() {
            // 12-Hours w/leading 0; 01..12
            return _pad(f.g(), 2)
        },
        H: function() {
            // 24-Hours w/leading 0; 00..23
            return _pad(f.G(), 2)
        },
        i: function() {
            // Minutes w/leading 0; 00..59
            return _pad(jsdate.getMinutes(), 2)
        },
        s: function() {
            // Seconds w/leading 0; 00..59
            return _pad(jsdate.getSeconds(), 2)
        },
        u: function() {
            // Microseconds; 000000-999000
            return _pad(jsdate.getMilliseconds() * 1000, 6)
        },

        // Timezone
        e: function() {
            // Timezone identifier; e.g. Atlantic/Azores, ...
            // The following works, but requires inclusion of the very large
            // timezone_abbreviations_list() function.
            /*              return that.date_default_timezone_get();
             */
            var msg = 'Not supported (see source code of date() for timezone on how to add support)'
            throw new Error(msg)
        },
        I: function() {
            // DST observed?; 0 or 1
            // Compares Jan 1 minus Jan 1 UTC to Jul 1 minus Jul 1 UTC.
            // If they are not equal, then DST is observed.
            var a = new Date(f.Y(), 0)
            // Jan 1
            var c = Date.UTC(f.Y(), 0)
            // Jan 1 UTC
            var b = new Date(f.Y(), 6)
            // Jul 1
            // Jul 1 UTC
            var d = Date.UTC(f.Y(), 6)
            return ((a - c) !== (b - d)) ? 1 : 0
        },
        O: function() {
            // Difference to GMT in hour format; e.g. +0200
            var tzo = jsdate.getTimezoneOffset()
            var a = Math.abs(tzo)
            return (tzo > 0 ? '-' : '+') + _pad(Math.floor(a / 60) * 100 + a % 60, 4)
        },
        P: function() {
            // Difference to GMT w/colon; e.g. +02:00
            var O = f.O()
            return (O.substr(0, 3) + ':' + O.substr(3, 2))
        },
        T: function() {
            // The following works, but requires inclusion of the very
            // large timezone_abbreviations_list() function.
            /*              var abbr, i, os, _default;
            if (!tal.length) {
              tal = that.timezone_abbreviations_list();
            }
            if ($locutus && $locutus.default_timezone) {
              _default = $locutus.default_timezone;
              for (abbr in tal) {
                for (i = 0; i < tal[abbr].length; i++) {
                  if (tal[abbr][i].timezone_id === _default) {
                    return abbr.toUpperCase();
                  }
                }
              }
            }
            for (abbr in tal) {
              for (i = 0; i < tal[abbr].length; i++) {
                os = -jsdate.getTimezoneOffset() * 60;
                if (tal[abbr][i].offset === os) {
                  return abbr.toUpperCase();
                }
              }
            }
            */
            return 'UTC'
        },
        Z: function() {
            // Timezone offset in seconds (-43200...50400)
            return -jsdate.getTimezoneOffset() * 60
        },

        // Full Date/Time
        c: function() {
            // ISO-8601 date.
            return 'Y-m-d\\TH:i:sP'.replace(formatChr, formatChrCb)
        },
        r: function() {
            // RFC 2822
            return 'D, d M Y H:i:s O'.replace(formatChr, formatChrCb)
        },
        U: function() {
            // Seconds since UNIX epoch
            return jsdate / 1000 | 0
        }
    }

    var _date = function(format, timestamp) {
        jsdate = (timestamp === undefined ? new Date() // Not provided
            :
            (timestamp instanceof Date) ? new Date(timestamp) // JS Date()
            :
            new Date(timestamp * 1000) // UNIX timestamp (auto-convert to int)
        )
        return format.replace(formatChr, formatChrCb)
    }

    return _date(format, timestamp)
}
Util.keyInObj = function(value, obj) {
    for (var key in obj) {
        if (obj[key] == value) {
            return key;
        }
    }
}
//判断元素是否在数组内
Util.contains = function(arr, obj) {
    if (arr) {
        var i = arr.length;
        while (i--) {
            if (arr[i] === obj) {
                return true;
            }
        }
        return false;
    } else {
        return false;
    }
}
Util.renderSize = function(value) {
    if (null == value || value == '') {
        return "0Bytes";
    }
    var unitArr = new Array("Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB");
    var index = 0;
    var srcsize = parseFloat(value);
    index = Math.floor(Math.log(srcsize) / Math.log(1024));
    var size = srcsize / Math.pow(1024, index);
    size = size.toFixed(2); //保留的小数位数
    return size + unitArr[index];
}
module.exports = Util